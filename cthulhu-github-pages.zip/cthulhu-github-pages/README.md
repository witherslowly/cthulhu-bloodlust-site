# CTHULHU BloodLust Studio — GitHub Pages starter

**DRAFT — review and complete policies before making the site public.** Replace the operator/contact placeholder in privacy.html and terms.html. Verify every statement against the real product's current privacy and credential handling.

1. Create a PUBLIC GitHub repository called `cthulhu-bloodlust-site`.
2. Upload index.html, privacy.html, terms.html, style.css to the repository root.
3. Open Settings → Pages → Build and deployment → Deploy from a branch → main → /(root) → Save.
4. Once GitHub Pages reports a successful deployment, the URLs are generally:
   - https://YOUR-GITHUB-USERNAME.github.io/cthulhu-bloodlust-site/
   - https://YOUR-GITHUB-USERNAME.github.io/cthulhu-bloodlust-site/privacy.html
   - https://YOUR-GITHUB-USERNAME.github.io/cthulhu-bloodlust-site/terms.html
5. Test URLs publicly. TikTok may require domain or URL ownership verification and review; GitHub Pages availability alone does not imply approval.

Do NOT commit OAuth keys, client secrets, access tokens or user data to the website repository.
